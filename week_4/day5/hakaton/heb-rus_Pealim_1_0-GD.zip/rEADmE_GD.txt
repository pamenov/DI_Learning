Version for GoldenDict (UTF-8)
..............................
Enjoy!
� EdwART