Version for GoldenDict (UTF-8)
Put *.dz to Dictionaries Directory
..............................
Enjoy!
� EdwART